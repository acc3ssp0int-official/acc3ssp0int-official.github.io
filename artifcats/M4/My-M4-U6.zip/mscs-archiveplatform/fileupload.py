import sys
import os
import magic
import shutil

# Get the file path from the command line argument 
# [ This simulates the file upload as it would be on from a frontend form ]
file_path = input("Enter the file path: ")


# Check if the file has a valid extension
# Validates if the uploaded file has the valid extensions against an allowed-list of pdf and docx
# This prevents other content extensions to be passed into the system and creating malformed files
valid_extensions = ['.pdf', '.docx']
_, file_extension = os.path.splitext(file_path)
if file_extension not in valid_extensions:
    print("Invalid file! The application only accepts '.pdf' or '.docx' extensions")
    sys.exit(1)

# Check if the file has the correct content type
# Validates if the uploaded file has the required content-type against an allowed-list of pdf and docx. 
# This prevents other content types to be passed into the system and creating malformed files
mime = magic.Magic(mime=True)
content_type = mime.from_file(file_path)
if file_extension == '.pdf' and content_type != 'application/pdf':
    print("Invalid content type for PDF file!")
    sys.exit(1)
elif file_extension == '.docx' and content_type != 'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
    print("Invalid content type for DOCX file!")
    sys.exit(1)

# Check if the file is larger than 10 MB
# Validates if the uploaded file has is within the file limit.
# This prevents huge files to enter the systems [such as zip bombs] and overload and potentially DOS the system
file_size = os.path.getsize(file_path)
if file_size > 10 * 1024 * 1024:
    print("File is too large! Reduce the file size to under 10 Megabytes")
    sys.exit(1)

# Check if the file has multiple extensions
# Validates if the file only is allowing a single extension. multiple extensions could potentially allow files to bypass the allow list
# This prevents .pdf.php or .docx.py or similar malformed files to enter the system.
if '.' in file_path.split(os.path.extsep, 1)[1]:
    print("Multiple extensions are prohibited!")
    sys.exit(1)

# This portion of the app simulates that the file is uploaded
# Given this is a CLI only function code /tmp/UploadedFiles directory simulates the secured storage of the system.
# This prevents unauthorized file access and would be locked down for a specific user.
upload_dir = '/tmp/UploadedFiles'
if not os.path.exists(upload_dir):
    os.makedirs(upload_dir)
shutil.copy(file_path, upload_dir)
print("Success! The file has been uploaded to our system")
