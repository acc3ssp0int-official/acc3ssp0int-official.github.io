# Module Assignment 2: Archive CMS

A **Content Management Platform** aimed to centralize the file management for `the Dutch Police Internet Forensics (Government of the Netherlands, n.d.).` and enable them to maintain files in the system as per GDPR requirements.

**Note:** Due to lack of coding experience and expertise the current implementation only functions on the CLI [command line interface]

### Summary of the code
- login4.py: Simulates the logon function with sufficient password complexity checks.
- fileupload.py: Simulates the file upload with file upload restrictions to certain allowed file extensions, size, content-type and copies the successfully uploaded file to simulate a file upload.

### Summary of Limitations
Our **biggest limitation** was the **lack of experience with Django** and expertise to code in django where we decided to move back to a CLI functional code base.
- Limitations of login4.py: Because this is a CLI only code. Checks such as csrf-protection, session management, brute-force protection are not deployed.
- Limitations of fileupload.py: Because this is a CLI only code code checks such as csrf-protection and other form-field content checks are not deployed.


#### Usage
##### *Since this is a Proof-Of-Concept [POC] code and not a fully functional application;*
- Run the login4.py file as `python3 login4.py'
- Supply the user credentials as below [any one]

#
| ID      | Password |
| ----------- | ----------- |
| AAdmin     | Staging@2022       |
| AMgr   | Uploader@2022        |
###### Note password is hashed with sha256 in the database
- If the submitted password is correct, the application will wait at a prompt requesting a 6 Digit OTP code.
- At this point add dummy secret to google authenticator or 1password generated in the `db_secret.txt` section, using the [+] icon in the app.
- Submit the `OTP` generated on Google Authenticator.
- Press authenticate
#
| ID      | Secret |
| ----------- | ----------- |
| AAdmin     | PAM7X3XELZJDMB5B7QJZRBZVBXF3JHOS       |
| AMgr   | BDBWALE3CEK4RL35EOMQ34GHFBJ2IXXS        |

### Setup and Install Guide

To setup the project please run through the following steps; [You can also copy paste the commands as it is for simplicity]

Copy the `Final.zip` to a Ubuntu-system for installation:

`Unzip` the archive using:
```sh
unzip Final.zip
```
`Move` into the newly created Final directory:
```sh
cd Final/
```
`Install` dependancies using requirements.txt:
```sh
sudo pip3 install -r requirements.txt
```
Copy `Environment variables` and export to terminal:
```sh
export DB_USER=projroot
export DB_PASSWORD=New@2022
export DB_HOST=localhost
export DB_NAME=pycli
```
Setup your mysql-server with the root password as you require and run the following
```sql
---Create user for the project---
CREATE USER 'projroot'@'localhost' IDENTIFIED WITH mysql_native_password BY 'New@2022';

---Create database for the project---
CREATE DATABASE pycli;
GRANT ALL ON pycli.* TO 'projroot'@'localhost';
use DATABASE pycli;

---Create tables for the project---
CREATE TABLE secret (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    secret VARCHAR(32) NOT NULL
);

CREATE TABLE husers (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    username VARCHAR(255) NOT NULL UNIQUE,
    password VCHAR(255) NOT NULL
);

---Create test data for the project---

INSERT INTO husers (username, password) VALUES
('AAdmin', SHA2('Staging@2022', 256)),
('AMgr', SHA2('Uploader@2022', 256));

INSERT INTO secret (username, secret) VALUES ('AAdmin', 'PAM7X3XELZJDMB5B7QJZRBZVBXF3JHOS');
INSERT INTO secret (username, secret) VALUES ('AMgr', 'BDBWALE3CEK4RL35EOMQ34GHFBJ2IXXS');
```
#### Please Note [POC only setup]:
- Database is set with a non-secure simple password as `New@2022`
- The current implementation does not allow creation of users unless added directly to the database
- Secret generated for Authenticator is not converted and served as a QR code.
- Generated secret length is short to keep the manual efforts minimal. [Making it Insecure by nature]

### References
- STechies. (n.d.). How to Upload Files in Python? Available from: https://www.stechies.com/upload-files-python/ [Accessed 18 Dec. 2022].
- Stack Overflow. (n.d.). Simple login function in Python. Available from: https://stackoverflow.com/questions/28483113/simple-login-function-in-python [Accessed 18 Dec. 2022].
- Prakash, Y. (2021). The Quick Guide To Using Environment Variables in Python. Medium. Available from: https://towardsdatascience.com/the-quick-guide-to-using-environment-variables-in-python-d4ec9291619e [Accessed 18 Dec. 2022].
- Able. (n.d.). How to Set and Get Environment Variables in Python. Available from: https://able.bio/rhett/how-to-set-and-get-environment-variables-in-python--274rgt5 [Accessed 18 Dec. 2022].