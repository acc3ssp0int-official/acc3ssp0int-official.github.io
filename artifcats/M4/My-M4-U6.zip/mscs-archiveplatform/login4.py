import mysql.connector
import re
import os
import pyotp
import hashlib
import sys

# Read the command line arguments
# This input simluates the login fields of a form
username = input("Enter Your Username: ")
password = input("Enter Your Password: ")

# This check prevents null passwords and IDs to be submitted into the code
if username == '' or password == '':
    print("Please Enter Valid Credentials!!")
    exit() 


# Function to check if password meets the required criteria
def check_password_criteria(password):
  # Check if password has 1 uppercase, 1 lowercase, 1 special character, and minimum 8 characters
  if not any(char.isdigit() for char in password):
    return False
  if not any(char.isupper() for char in password):
    return False
  if not any(char.islower() for char in password):
    return False
  if not any(char in set(r'[~!@#$%^&*()_+{}":;\']+$') for char in password):
    return False
  if len(password) < 8:
    return False
  return True

# The above function gets called here; verifies even the submitted password follows password complexity requirements.
if check_password_criteria(password) == False:
    print("Password Entered does not match the required critera!!")
    exit()
# Connect to the database using the environment variables
# This prevents hard coding credentials into the file allowing anyone to read it if the file is left accessible.
cnx = mysql.connector.connect(user=os.environ['DB_USER'], password=os.environ['DB_PASSWORD'],
                                  host=os.environ['DB_HOST'],
                                  database=os.environ['DB_NAME'])

# This query the database to fetch the password against a valid username 
query = "SELECT password FROM husers WHERE username = %s"
cursor = cnx.cursor()
cursor.execute(query, (username,))

hashed_password = cursor.fetchone()[0]
# This query the database verifies password against a valid username and if the submitted password is valid
# The hashlib of sha256 is used as our stored password is hashed with the same.
# The library hashes the submitted input with sha256 and attempts to match it to the 'hashed_password' fetched earlier.
if hashlib.sha256(password.encode()).hexdigest() == hashed_password:
    print("Login On Verified, Success!")
    # If the credentials are correct upto this point a new 6 digit code is prompted by the system.
    code = input("Please Enter your 6 Digit OTP Code: ")
    # This query fetches the user's secret key from the database
    query = "SELECT secret FROM secret WHERE username = %s"
    cursor.execute(query, (username,))
    secret_key = cursor.fetchone()[0]

    # The fetched secret key is passed into pyOTP's totp function to verify the code submitted by the user by regenerating the same value.
    totp = pyotp.TOTP(secret_key)
    if totp.verify(code):
        print("Login Successful; Welcome to Archive CMS Platform!")
    else:
        print("Failure! Invalid Code Please Try Again!")

else:
    print("Failure Invalid Logon Credentials, Please Try Again!!")

# Close the connection to the database
cnx.close()